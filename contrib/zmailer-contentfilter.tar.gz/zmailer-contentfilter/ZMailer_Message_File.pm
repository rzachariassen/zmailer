## This is ada.dhs.org:/usr/local/lib/ZMailer_Message_File.pm
## $Header: /var/src/zmailer-contentfilter/RCS/ZMailer_Message_File.pm,v 4.2 2000/10/05 02:49:29 acli Exp $
##
## Derived from smtp-contentfilter, which is
## derived from the outdated version of ckfreezer at home :-(
## Hope that this is a reusable FSM for both ckfreezer and smtp-contentfilter
##
## Copyright 1998, 2000 by Ambrose Li <acli@ada.dhs.org>

package ZMailer_Message_File;

use integer;
use strict;

use MIME::Base64;
use MIME::QuotedPrint;

## FSM state numbers
sub START                      () { -1 };
sub ENVELOPE                   () { 0 };
sub HEAD                       () { 1 };
sub BODY                       () { 2 };
sub PREAMBLE                   () { 3 };
sub ATTACHMENT_HEAD            () { 4 };
sub ATTACHMENT_BODY            () { 5 };
sub ATTACHMENT_PREAMBLE        () { 6 };
sub ATTACHMENT_POSTAMBLE       () { 7 };
sub POSTAMBLE                  () { 8 };
sub ATTACHED_MESSAGE_HEAD      () { 9 };
sub ATTACHED_MESSAGE_BODY      () { 10 };
sub ATTACHED_MESSAGE_PREAMBLE  () { 11 };
sub ATTACHED_MESSAGE_POSTAMBLE () { 12 };

BEGIN {
   use Exporter   ();
   use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

   $VERSION = do { my @r = (q$Revision: 4.2 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

   @ISA         = qw(Exporter);
   @EXPORT      = qw( );
   %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

   # your exported package globals go here,
   # as well as any optionally exported functions
   @EXPORT_OK   = qw(
      $debug
      &ENVELOPE &HEAD &BODY &PREAMBLE &POSTAMBLE
      &ATTACHMENT_HEAD &ATTACHMENT_BODY
      &ATTACHMENT_PREAMBLE &ATTACHMENT_POSTAMBLE
      &ATTACHED_MESSAGE_HEAD &ATTACHED_MESSAGE_BODY
      &ATTACHED_MESSAGE_PREAMBLE &ATTACHED_MESSAGE_POSTAMBLE
   );
}
use vars @EXPORT_OK;

BEGIN {
   use vars qw( $rcsLocker $rcsDate );
   $rcsDate   = q$Date: 2000/10/05 02:49:29 $;
   $rcsLocker = q$Locker:  $;
}

use vars qw(%fsm_state_cvs);
%fsm_state_cvs = (
   &START                      => 'START',
   &ENVELOPE                   => 'ENVELOPE',
   &HEAD                       => 'HEAD',
   &BODY                       => 'BODY',
   &PREAMBLE                   => 'PREAMBLE',
   &ATTACHMENT_HEAD            => 'ATTACHMENT_HEAD',
   &ATTACHMENT_BODY            => 'ATTACHMENT_BODY',
   &ATTACHMENT_PREAMBLE        => 'ATTACHMENT_PREAMBLE',
   &ATTACHMENT_POSTAMBLE       => 'ATTACHMENT_POSTAMBLE',
   &POSTAMBLE                  => 'POSTAMBLE',
   &ATTACHED_MESSAGE_HEAD      => 'ATTACHED_MESSAGE_HEAD',
   &ATTACHED_MESSAGE_BODY      => 'ATTACHED_MESSAGE_BODY',
   &ATTACHED_MESSAGE_PREAMBLE  => 'ATTACHED_MESSAGE_PREAMBLE',
   &ATTACHED_MESSAGE_POSTAMBLE => 'ATTACHED_MESSAGE_POSTAMBLE',
);

sub state_cvs ($) {
   my($s) = @_;
   $fsm_state_cvs{$s};
}

sub state_is_head_p ($) {
   my($state) = @_;
   return ($state == HEAD
      || $state == ATTACHMENT_HEAD
      || $state == ATTACHED_MESSAGE_HEAD);
}

sub state_is_body_p ($) {
   my($state) = @_;
   return ($state == BODY
      || $state == ATTACHMENT_BODY
      || $state == ATTACHED_MESSAGE_BODY);
}

sub state_is_junk_p ($) {
   my($state) = @_;
   return ($state == PREAMBLE
      || $state == POSTAMBLE
      || $state == ATTACHMENT_PREAMBLE
      || $state == ATTACHMENT_POSTAMBLE
      || $state == ATTACHED_MESSAGE_PREAMBLE
      || $state == ATTACHED_MESSAGE_POSTAMBLE);
}

## The scan() function scans the control file specified in the
## given path. This is a very simplistic deterministic FSM.
##
## The second argument, $f, specifies a closure of a function to be
## called between the input and state transition steps.
##
## The third argument, $g, specifies a closure of a function to be
## called after the FSM reaches an exit condition.

sub parse_content_type_header ($) {
   local ($_, $1, $2, $3, $4, $5, $6);
   my ($val) = @_;
   my ($major, $minor, $boundary);
   # See RFC 1341
   my $tspecials = quotemeta("()<>\@,;:\\\"/[]?.=");
   my %dict;
   if ($val =~ /^([^$tspecials]+)\/([^$tspecials]+)(.*)$/) {
      ($major, $minor, $val) = (lc($1), lc($2), $3);
      while ($val =~ /^\s*;\s*([^$tspecials]+)\s*=\s*("([^"]*)"|([^\s$tspecials]*))(\s*(.*))?$/) {
	 my ($k, $v, $rest) = ($1, $2, $6);
	 $v = $1 if $v =~ /^"(.*)"$/;
	 $dict{lc($k)} = $v;
	 $val = $rest;
      }
      $boundary = $dict{boundary} if $major eq 'multipart';
   }
   print STDERR "content-type: $major/$minor ; boundary=($boundary)\n"
      if $debug > 0;
   warn "$$: parse_content_type_header: Invalid header left over \"$val\"\n"
      if $val =~ /\S/;
   return ($major, $minor, $boundary);
}

sub attachment_number_cvs (@) {
   return join('.', @_) || '0';
}

sub protected_scalar_eval {
   my($f, @x) = @_;
   my $save_ = $_;
   my $it = &$f(@x);
   $_ = $save_;
   return $it;
}

sub scan ($;$$$$) {
   my ($file, $f, $g, $p, $q) = @_; # p, q are exit conditions
   local *INPUT;
   if (open(INPUT, '<'.$file)) {
      my $state = ENVELOPE;
      my $prev_state;		# for instrumentation only
      my $prev_attachment_number;	# ditto
      my %envelope;		# rcvdfrom, with, identinfo, todsn, to
      my %header;		# from, sender, to, subject,...
      my $originating_ip;	# extracted from inside rcvdfrom
      my @boundary_stack;	# non-current boundaries
      my $message_size;
      my($boundary, $type, $subtype, @transfer_encoding);
      my(@attachment_number, @state_stack);
      my $readahead;

      my $read = sub {
	 local $_;
	 my $it;
	 if (defined $readahead) {
	    $it = $readahead;
	    $readahead = undef;
	    print STDERR "readahead (state $fsm_state_cvs{$state}) ($it)\n"
	       if $debug > 9;
	 } else {
	    $it = scalar <INPUT>;
	    print STDERR "read (state fsm_state_cvs{$state}) ($it)\n"
	       if $debug > 9;
	    if ($it !~ /^--/ && @transfer_encoding) {
	       print STDERR 'encoding is ', join('.', @transfer_encoding), "\n"
		  if $debug > 8;
	       for my $transfer_encoding (reverse @transfer_encoding) {
		  if ($transfer_encoding =~ /^base64$/i) {
		     $it = decode_base64($it);
		     print STDERR "decoded from base64 ($it)\n" if $debug > 8;
		  } elsif ($transfer_encoding =~ /^quoted-printable$/i) {
		     while ($it =~ /^(.*)=(\n?)$/) { # continuation line
			$it = $1;
			$it .= scalar <INPUT>;
		     }
		     $it = decode_qp($it);
		     print STDERR "decoded from qp ($it)\n" if $debug > 8;
		  } elsif ($transfer_encoding =~ /^x-uuencode$/i) {
		     $it = unpack('u', $it);;
		     print STDERR "decoded from uuencode ($it)\n" if $debug > 8;
		  }
	       }
	    }
	 }
	 return $it;
      };

      my $continuation_lines = sub {
	 local $_;
	 my $val = '';
	 for (;;) {
	    $readahead = &$read;		# read ahead
	 last if $readahead =~ /^(\S|\n|$)/;
	    $val =~ s/\r?\n$/ /;
	    $val .= $1 if $readahead =~ /^\s+(\S.*)$/s;
	    $readahead = undef;
	 }
	 return $val;
      };

      my $save = sub {
	 # XXX we can't save @boundary_stack because it contains the stack depth
	 # XXX this is arguably wrong and should be fixed
	 my($state, $dont_increment_attachment_number_p) = @_;
	 push @attachment_number, 1 unless $dont_increment_attachment_number_p;
	 push @state_stack, [$state, $boundary, $type, $subtype,
	    [@attachment_number],
	    @transfer_encoding];
	 print STDERR "state saved, stack length now ", 0 + @state_stack, "\n"
	    if $debug;
      };

      my $restore = sub {
	 my($_1, $_2);
	 ($state, $boundary, $type, $subtype, $_1, @transfer_encoding)
	    = @{ pop @state_stack };
	 @attachment_number = @$_1;
	 print STDERR "state restored, stack length now ", 0 + @state_stack,
	       ": (state $fsm_state_cvs{$state}, boundary $boundary, ",
	       "$type/$subtype), ",
	       'transfer encoding (', join(', ', @transfer_encoding), ')',
	       "\n"
	    if $debug;
      };

      my $new_boundary = sub {
	 my($next_boundary) = @_;
	 print STDERR "new boundary $next_boundary\n" if $debug;
	 push @boundary_stack, [$boundary, scalar(@state_stack)];
	 $boundary = $next_boundary;
      };

      my $new_transfer_encoding = sub {
	 my($encoding) = @_;
	 push @transfer_encoding, lc($encoding)
	    if length $encoding && $encoding !~ /^\dbit$/i;
      };

      my $match_boundary = sub {
	 my($s) = @_;
	 my($matched_p, $last_p, $level);
	 if ($s =~ /^--/) {
	    chomp $s;
	    print STDERR "input is ($s)\n" if $debug;
	    print STDERR "checking current boundary ($boundary)\n" if $debug;
	    if (length $boundary && $s eq "--$boundary") {
	       ($matched_p, $last_p, $level) = (1, 0, 0);
	    } elsif (length $boundary && $s eq "--$boundary--") {
	       ($matched_p, $last_p, $level) = (1, 1, 0);
	    }
	    if (!$matched_p) {
	       for (my $i = $#boundary_stack; $i >= 0; $i -= 1) {
		  my($boundary, $stack_size) = @{$boundary_stack[$i]};
		  print STDERR "checking stack[$i], boundary ($boundary)\n"
		     if $debug;
		  if (length $boundary && $s eq "--$boundary") {
		     ($matched_p, $last_p, $level)
			= (1, 0, @boundary_stack - $i);
		  } elsif (length $boundary && $s eq "--$boundary--") {
		     ($matched_p, $last_p, $level)
			= (1, 1, @boundary_stack - $i);
		  }
		  if ($matched_p) { # then we need to adjust both stacks
		     splice @boundary_stack, $i;
		     # Need to call &$restore because of attachment number
		     while (@state_stack > $stack_size) {
			&$restore;
		     }
		  }
	       last if $matched_p;
	       }
	    }
	    print STDERR !$matched_p? "not matched\n":
		  $last_p? "matched (terminal)\n": "matched (medial)\n"
	       if $debug;
	 }
	 return ($matched_p, $last_p, $level);
      };

      for (my($next_type, $next_subtype, $next_boundary, $next_transfer_encoding);;) {
	 $_ = &$read;
      last unless length $_;
	 $message_size += length;
	 if ($state == HEAD
	    || $state == ATTACHMENT_HEAD
	    || $state == ATTACHED_MESSAGE_HEAD
	 ) {
	    my $next = &$continuation_lines;
	    if (length $next) {
	       chomp;
	       $_ .= $next;
	    }
	 }
	 if ($debug) {				# for instrumentation only
	    my $attachment_number = attachment_number_cvs(@attachment_number);
	    printf STDERR "attachment number is %s %s\n",
		  ($prev_attachment_number ne $attachment_number?
		     'now': 'still'),
		  attachment_number_cvs(@attachment_number),
	       if $prev_state != $state;
	    print STDERR (($prev_state == $state?
			   '': "$fsm_state_cvs{$prev_state} -> "),
			   "$fsm_state_cvs{$state} ($_)\n")
	       if $debug > 2;
	    $prev_state = $state;
	    $prev_attachment_number = $attachment_number;
	 }
	 protected_scalar_eval($f, $state, $_, $type, $subtype) if defined $f;
      last if defined $p && protected_scalar_eval($p, $state, $_, $type, $subtype, $message_size);
	 if ($state == ENVELOPE) {
	    if (/^env-end$/) {
	       $state = HEAD;
	    } elsif (/^From /) {		# Unix MBOX From_ header
	       $state = HEAD;
	    } elsif (/^(\S+)\s+(.*)$/) {	# key-value pairs
	       $envelope{$1} = $2;
	       $originating_ip = $1
		     if $1 eq 'rcvdfrom' && $2 =~ /\[(\d+\.\d+\.\d+\.\d+)\]:/;
	    } else {				# boolean parameters
	       $envelope{$_} = '';
	    }
	 } elsif ($state == HEAD) {
	    if (/^$/) {
	       if ($type eq 'message') {
		  &$save;			# should have no next state!
		  ($type, $subtype, $boundary) = ();
		  $state = ATTACHED_MESSAGE_HEAD;
	       } else {
		  $state = length $boundary? PREAMBLE: BODY;
	       }
	    } elsif (/^(\S+):\s*(\S.*)\s*$/) {	# This should always be the case
	       my($key, $val) = (lc($1), $2);
	       $header{$key} = $val;
	       ($type, $subtype, $boundary) = parse_content_type_header $val
		  if $key eq 'content-type';
	       &$new_transfer_encoding($val)
		  if $key eq 'content-transfer-encoding';
	    }
	 } elsif ($state == BODY) {
	    ;
	 } elsif ($state == PREAMBLE) {
	    my($matched_p, $last_p) = &$match_boundary($_);
	    if ($matched_p && !$last_p) {
	       &$save(POSTAMBLE);
	       ($type, $subtype) = ();
	       $state = ATTACHMENT_HEAD;
	    } elsif ($matched_p && $last_p) { # unlikely
	       $state = POSTAMBLE;
	    }
	 } elsif ($state == ATTACHMENT_HEAD) {
	    if (/^$/) {
	       print STDERR "GOT HERE! type=$type, next_type=$next_type\n"
		  if $debug > 3;
	       if ($next_type eq 'message') {
		  &$new_boundary($boundary);
		  &$save(ATTACHMENT_BODY, 1);
		  ($type, $subtype) = ();
		  $state = ATTACHED_MESSAGE_HEAD;
	       } else {
		  $state = length $next_boundary?
			   ATTACHMENT_PREAMBLE: ATTACHMENT_BODY;
	       }
	       ($type, $subtype) = ($next_type, $next_subtype);
	       &$new_transfer_encoding($next_transfer_encoding);
	       ($next_type, $next_subtype, $next_transfer_encoding) = ();
	       if (length $next_boundary) {
		  $boundary = $next_boundary;
		  $next_boundary = undef;
		  $next_transfer_encoding = undef;
	       }
	    } elsif (/^(\S+):\s*(.*)\s*$/) {	# This should always be the case
	       my($key, $val) = (lc($1), $2);
	       $val .= &$continuation_lines;
	       ($next_type, $next_subtype, $next_boundary)
		     = parse_content_type_header $val
		  if $key eq 'content-type';
	       $next_transfer_encoding = $val
		  if $key eq 'content-transfer-encoding';
	    }
	 } elsif ($state == ATTACHMENT_BODY
	       || $state == ATTACHMENT_POSTAMBLE
	       || $state == ATTACHED_MESSAGE_BODY
	       || $state == ATTACHED_MESSAGE_POSTAMBLE
	 ) {
	    my($matched_p, $last_p) = &$match_boundary($_);
	    printf STDERR "GOT GOT HERE HERE!!!! $matched_p $last_p\n"
	       if $debug > 3 && defined $last_p;
	    if ($matched_p && !$last_p) {
	       $attachment_number[$#attachment_number] += 1;
	       ($type, $subtype) = ();
	       $state = ATTACHMENT_HEAD;
	    } elsif ($matched_p && $last_p) {
	       &$restore;
	    }
	 } elsif ($state == ATTACHMENT_PREAMBLE) {
	    my($matched_p, $last_p) = &$match_boundary($_);
	    if ($matched_p && !$last_p) {
	       &$save(ATTACHMENT_POSTAMBLE);
	       ($type, $subtype) = ();
	       $state = ATTACHMENT_HEAD;
	    } elsif ($matched_p && $last_p) { # unlikely
	       &$restore;
	    }
	 } elsif ($state == POSTAMBLE) {
	    ;
	 } elsif ($state == ATTACHED_MESSAGE_HEAD) {
	    if (/^$/) {
	       if ($type eq 'message') {
		  &$save(ATTACHED_MESSAGE_BODY, 1);
		  ($type, $subtype) = ();
		  $state = ATTACHED_MESSAGE_BODY;
	       } else {
		  $state = length $boundary?
			   ATTACHED_MESSAGE_PREAMBLE: ATTACHED_MESSAGE_BODY;
	       }
	    } elsif (/^(\S+):\s*(.*)\s*$/) {	# This should always be the case
	       my($key, $val) = (lc($1), $2);
	       ($type, $subtype, $boundary) = parse_content_type_header $val
		  if $key eq 'content-type';
	       &$new_transfer_encoding($val)
		  if $key eq 'content-transfer-encoding';
	    }
	 } elsif ($state == ATTACHED_MESSAGE_PREAMBLE) {
	    my($matched_p, $last_p) = &$match_boundary($_);
	    if ($matched_p && !$last_p) {
	       &$save(ATTACHED_MESSAGE_POSTAMBLE);
	       ($type, $subtype) = ();
	       $state = ATTACHMENT_HEAD;
	    } elsif ($matched_p && $last_p) { # unlikely
	       $state = ATTACHED_MESSAGE_POSTAMBLE;
	    }
	 } else {				# This should never happen
	    die "Internal error: unknown state $state encountered\n";
	 }
      last if defined $q && protected_scalar_eval($q, $state, $_, $type, $subtype, $message_size);
      }
      close INPUT;
      &$g($state) if defined $g;
   } else {
      die "$file: open: $!\n";
   }
}

END {}

1;
