## This is ada.dhs.org:/usr/local/lib/Spamdex.pm
## $Header: /var/src/zmailer-contentfilter/RCS/Spamdex.pm,v 2.13 2000/10/05 02:49:08 acli Exp $
##
## spamdex function extracted from ckfreezer
## Copyright 1998, 2000 by Ambrose Li <acli@ada.dhs.org>

package Spamdex;

use integer;
use strict;

BEGIN {
   use Exporter   ();
   use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

   $VERSION = do { my @r = (q$Revision: 2.13 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

   @ISA         = qw(Exporter);
   @EXPORT      = qw(&spamdex);
   %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

   # your exported package globals go here,
   # as well as any optionally exported functions
   @EXPORT_OK   = qw();
}
use vars @EXPORT_OK;

use vars qw( $config_file $config_file_read_p );
use vars qw( $debug );
use vars qw( $threshold %translation );
use vars qw( %weight_gen %weight_env %weight_head %weight_html );

BEGIN {
   use vars qw( $rcsLocker $rcsDate );
   $rcsDate   = q$Date: 2000/10/05 02:49:08 $;
   $rcsLocker = q$Locker:  $;
}

## BEGIN tunable parameters

$config_file = '/etc/spam.conf';
$threshold = 3;				# overridable in $config_file

sub read_config_file () {
   local *INPUT;
   if (open(INPUT, '<'.$config_file)) {
      my $section;
      while (<INPUT>) {
	 next if /^\s*($|#)/;
	 if (/^\[(.*)\]\s*($|#)/) {
	    $section = lc($1);
	    warn "$$: Unknown section $section\n"
		  unless $section eq 'options'
		      || $section eq 'translations'
		      || $section eq 'weights';
	 } elsif (/^(.*\S)(\s*)=\s*([+-]?\d+)(?:\s*<<(?:(RE)|(GENERIC)|(ENV)|(HEAD)|(HTML))>>)*\s*($|#)/) {
	    my($key, $space, $val, $re_p, $generic_p, $env_p, $head_p, $html_p) = ($1, $2, $3, $4, $5, $6, $7, $8);
	    $generic_p = 1 unless $env_p || $head_p || $html_p;
	    $key .= substr($space, 0, 1) if $re_p && $key =~ /\\$/;
	    if (!$re_p && $section ne 'options') {
	       my $key0 = $key;
	       $key =~ s/\s+/ /g;
	       $key = quotemeta($key);
	       $key = '\b'.$key unless $key0 =~ /^\W/;
	       $key .= '\b' unless $key0 =~ /\W$/;
	       $key =~ s/\\ /\\s\+/g;
	       $key = '(?i)' . $key; # case-insensitive match
	    }
	    print STDERR "[$section] /$key/ => $val",
		  ($env_p? ' <<ENV>>': ''),
		  ($head_p? ' <<HEAD>>': ''),
		  ($html_p? ' <<HTML>>': ''),
		  "\n"
	       if $debug > 10;
	    if ($section eq 'weights') {
	       $weight_gen {$key} = $val if $generic_p;
	       $weight_env {$key} = $val if $env_p;
	       $weight_head{$key} = $val if $head_p;
	       $weight_html{$key} = $val if $html_p;
	    } elsif (!$generic_p) {
	       warn "$$: Non-generic keys do not make sense in [$section]\n";
	    } elsif ($section eq 'options') {
	       if ($key eq 'threshold') {
		  $threshold = $val + 0;
	       } else {
		  warn "$$: Unknown option $key\n"
	       }
	    } else {
	       warn "$$: Unknown $key = $val in [$section]\n";
	    }
	 } elsif (/^(.*\S)(\s*)=\s*(\S.*\S)\s*(<<RE>>)?\s*($|#)/) {
	    my($key, $space, $val, $re_p) = ($1, $2, $3, $4);
	    $key .= substr($space, 0, 1) if $re_p && $key =~ /\\$/;
	    if (!$re_p && $section ne 'options') {
	       $key = '\b'.$key unless $key =~ /^\W/;
	       $key .= '\b' unless $key =~ /\W$/;
	       $key =~ s/\s+/\\s\+/g;
	       $key = '(?i)' . $key; # case-insensitive match
	    }
	    print STDERR "[$section] /$key/ => $val\n" if $debug > 10;
	    if ($section eq 'translations') {
	       $translation{$key} = $val;
	    } else {
	       warn "$$: Unknown $key = $val in [$section]\n";
	    }
	 } else {
	    warn "$$: Syntax error in $_";
	 }
      }
      close INPUT;
      $config_file_read_p = 1;
   }
}

## The spamdex function examines a piece of suspicious string and try to guess
## if it is spam according to weights given in the dictionary %weights.

use vars qw( @keys );
use vars qw( $initialized_p $prev_env_p $prev_head_p $prev_html_p );
sub spamdex ($;$$$) {
   my ($s, $env_p, $head_p, $html_p) = @_;
   my $spamdex = 0;
   my $phrase;
   read_config_file unless $config_file_read_p;
   foreach my $re (keys %translation) {
      if ($s =~ s/$re/$translation{$re}/g) {
	 print STDERR "translated /$re/$translation{$re}/\n" if $debug > 1;
      }
   }
   my $weight = $env_p? \%weight_env:
	       $head_p? \%weight_head:
	       $html_p? \%weight_html: {};
   if (!$initialized_p
      || $prev_env_p != $env_p
      || $prev_head_p != $head_p
      || $prev_html_p != $html_p
   ) {
      @keys = (sort {length $b <=> length $a}(keys %$weight, keys %weight_gen));
      ($prev_env_p, $prev_head_p, $prev_html_p) = ($env_p, $head_p, $html_p);
   }
   foreach my $re (@keys) {
      my $s0 = $s;
      while ($s =~ s/$re//) {
	 my $ok = 1;
	 my $val = defined $weight->{$re}? $weight->{$re}: $weight_gen{$re};
	 print STDERR "matched /$re/ (weight $val), now s=($s)\n"
	    if $debug > 1;
	 $spamdex += $val;
	 if ($s0 eq $s) {
	    warn "$$: regexp problem in /$re/, ignoring this no-op regexp\n";
	    if (defined $weight->{$re}) {
	       delete $weight->{$re};
	    } else {
	       delete $weight_gen{$re};
	    }
	    $ok = 0;
	 }
      last unless $ok;
      }
   }
   return $spamdex;
}

END {}

1;
