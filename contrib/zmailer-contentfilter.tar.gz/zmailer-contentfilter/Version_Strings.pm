## This is ada.dhs.org:/usr/local/lib/Version_Strings.pm
## $Header: /var/src/zmailer-contentfilter/RCS/Version_Strings.pm,v 1.7 2000/10/05 02:49:17 acli Exp $
##
## This module contains functions to construct various version strings from
## some variables in source files. The variable names are expected to be
##
## $rcsRevision     RCS Revision tag, for main program
## $rcsLocker       RCS Locker tag
## $rcsDate         RCS Date tag
## @Copyright       Copyright message
##
## The following kinds of version strings are constructed:
##
## user_agent       User-Agent string, for mail/news readers and web browsers
## version_option   Version information suitable for the --version GNU option
##
## Copyright 2000 by Ambrose Li <acli@ada.dhs.org>

package Version_Strings;

use integer;
use strict;

BEGIN {
   use Exporter   ();
   use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

   $VERSION = do { my @r = (q$Revision: 1.7 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

   @ISA         = qw(Exporter);
   @EXPORT      = qw();
   %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

   # your exported package globals go here,
   # as well as any optionally exported functions
   @EXPORT_OK   = qw( $appName );
}
use vars @EXPORT_OK;

BEGIN {
   use vars qw( $rcsLocker $rcsDate );
   $rcsDate   = q$Date: 2000/10/05 02:49:17 $;
   $rcsLocker = q$Locker:  $;
   $appName = $1 if $0 =~ /([^\/]+)$/; # must be true
}

sub _id ($$$$$) {
   my($sep, $name, $version, $date, $locker) = @_;
   my $it = $name;
   $it .= "$sep$1" if defined $version && $version =~ /^(?:Revision:\s*)?(\S+)\s*$/ && $1 ne '0.';
   my $comment;
   if (defined $date && $date =~ /^(?:Date:\s*)?(\d+\/\d+\/\d+)/) {
      $comment .= '; ' if defined $comment;
      $comment .= $1;
   }
   if (defined $locker && $locker =~ /^Locker:\s*(\S[^:]*[^:\s])\s*/) {
      $comment .= '; ' if defined $comment;
      $comment .= "under revision by $1";
   }
   $it .= " ($comment)" if defined $comment;
   return $it;
}

sub _id_main ($) {
   my($sep) = @_;
   return _id($sep, $appName, $main::rcsRevision, $main::rcsDate, $main::rcsLocker);
}

sub _id_module ($$) {
   my($sep, $name) = @_;
   my $rev = eval "\$${name}::VERSION";
   my $date = eval "\$${name}::rcsDate";
   my $locker = eval "\$${name}::rcsLocker";
   my $it;
   if (defined $rev || defined $date || defined $locker) {
      $it = _id($sep, $name, $rev, $date, $locker);
   }
   return $it;
}

## These functions receive a list of module names as arguments

sub user_agent (@) {
   my @symtab = @_;
   my $it = _id_main('/');
   for my $name (@symtab) {
      my $suffix = _id_module('/', $name);
      $it .= ' ' . $suffix if defined $suffix;
   }
   return $it;
}

sub version_option (@) {
   my @symtab = @_;
   my $it = 'This is ' . _id_main(' ');
   $it .= "\n" . join("\n", @main::Copyright) if @main::Copyright;
   if (@symtab) {
      $it .= "\n\nAdditional version information:";
      for my $name (@symtab) {
	 my $suffix = _id_module(' ', $name);
	 $it .= "\n" . $suffix if defined $suffix;
      }
   }
   return $it;
}

END {}

1;
