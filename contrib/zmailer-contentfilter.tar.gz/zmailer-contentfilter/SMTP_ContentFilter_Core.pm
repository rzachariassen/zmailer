#!/usr/bin/perl5
## This is ada.dhs.org:/usr/local/lib/SMTP_ContentFilter_Core.pm
## $Header: /var/src/zmailer-contentfilter/RCS/SMTP_ContentFilter_Core.pm,v 4.3 2000/10/05 02:50:59 acli Exp $
##
## Split from smtp-contentfilter, which is derived from ckfreezer
## Copyright 1998, 2000 by Ambrose Li <acli@ada.dhs.org>
##
## WARNING: You must be absolutely sure that this program works before you
## install it. ZMailer will happily accept Perl's syntax error message as
## a "0 Ok" message!
##
## (Not even warning messages are acceptable because of such careless
## behaviour. But it would be less possible to completely make sure there
## are no warning messages; sometimes you have to wrap components to make
## sure they don't misbehave. Or perhaps you could redirect stderr to a
## file immediately after the script begins, and hope that nothing went
## to stderr in the BEGIN blocks.)

package SMTP_ContentFilter_Core;

use integer;
use strict;
use Mail::Address;
use Spamdex;
use Version_Strings qw( $appName );
use ZMailer_Message_File;
use vars qw( $debug );
use vars qw( @selfaddresses @interface_addresses @local_networks );
use vars qw( $proctitlesuffix );

BEGIN {
   use Exporter   ();
   use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

   $VERSION = do { my @r = (q$Revision: 4.3 $ =~ /\d+/g); sprintf "%d."."%02d" x $#r, @r }; # must be all one line, for MakeMaker

   @ISA         = qw(Exporter);
   @EXPORT      = qw( );
   %EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

   # your exported package globals go here,
   # as well as any optionally exported functions
   @EXPORT_OK   = qw( );
}
use vars @EXPORT_OK;

BEGIN {
   use vars qw( $rcsLocker $rcsDate );
   $rcsDate     = q$Date: 2000/10/05 02:50:59 $;
   $rcsLocker   = q$Locker:  $;
}

## Tunable parameters
@local_networks = ('192.168/24');

## Auxiliary routines

sub get_self_addresses () {
   local *INPUT;
   my %addresses;
   for my $conf ('/etc/mail.conf', '/etc/zmailer.conf') {
      if (open(INPUT, '<'.$conf)) {
	 while (<INPUT>) {
	    if (/^orgdomain=(\S+)$/) {			# /etc/mail.conf
	       $addresses{$1} = 1;
	    } elsif (/^SELFADDRESSES=\s*(.*)\s*$/) {	# /etc/zmailer.conf
	       for my $address (split(/\s*,\s*/, $1)) {
		  $addresses{$address} = 1;
	       }
	    }
	 }
	 close INPUT;
      } else {
	 die "$conf: $!\n";
      }
   }
   @selfaddresses = keys %addresses;
   warn sprintf "self addresses = [%s]\n", join(', ', @selfaddresses) if $debug;
   @selfaddresses;
}

sub get_interface_addresses () {
   local *INPUT;
   my $ifconfig = '/sbin/ifconfig';
   my $pid = open(INPUT, '-|');
   die "$ifconfig: fork: $!" unless defined $pid;
   if (!$pid) {
      exec($ifconfig);
      die("$ifconfig: exec: $!\n");
   }
   my $inet_addr;
   my %interfaces;
   while (<INPUT>) {
      chomp;
      if (/inet addr:(\d+\.\d+\.\d+\.\d+)\b/) {
	 $inet_addr = $1;
      } elsif (/\bUP\b/) {
	 $interfaces{$inet_addr} = 1;
      } elsif (/^$/) {
	 $inet_addr = undef;
      }
   }
   close INPUT;
   @interface_addresses = keys %interfaces;
   warn sprintf "interfaces = [%s]\n", join(', ', @interface_addresses)
      if $debug;
   @interface_addresses;
}

## local_domain_p determines if the given address (with the enclosing <
## and >) is a local address

sub local_domain_p ($) {
   my ($s) = @_;
   my $it = 0;
   for my $address (@selfaddresses) {
      my $re = quotemeta($address);
      $it = 1 if $s =~ /(\@|\.)$re>$/i;
      warn "$s matched $address\n" if $debug && $it;
   last if $it;
   }
   return $it;
}

## local_ip_p determines if the given IP (in string form) is a local address

sub local_ip_p ($) {
   my ($s) = @_;
   my $s_ip = unpack('N', pack('c4', split(/\./, $s)));
   my $it = 0;
   for my $t (@interface_addresses, @local_networks) {
      my($t_ip, $mask);
      if ($t =~ /^(\d+\.\d+\.\d+\.\d+)\/(\d+)$/) {
	 ($t_ip, $mask) = (unpack('N', pack('c4', split(/\./, $1))), $2);
      } else {
	 ($t_ip, $mask) = (unpack('N', pack('c4', split(/\./, $t))), 32);
      }
      $mask = 0xffffffff >> (32 - $mask);
      $it = 1 if ($s_ip & $mask) == ($t_ip & $mask);
   last if $it;
   }
   return $it;
}

## Wrapper for Mail::Address->parse(). Needed because that function can call
## warn() ("Unmatched '<>' at /software/perl5/lib/site_perl/Mail/Address.pm
## line 189" in particular), which is really bad because ZMailer will treat
## the warning as a "0" (Ok) reply.

sub parse_mail_address ($) {
   my ($s) = @_;
   local *SAVE;
   unless ($debug > 0) {
      open(SAVE, '>&STDERR');
      open(STDERR, '>/dev/null');
   }
   print STDERR "parse_mail_address: entry: s=($s)\n" if $debug > 0;
   my @it = Mail::Address->parse($s);
   open(STDERR, '>&SAVE') unless $debug > 0;
   print STDERR "parse_mail_address: exit: returning (",
      join(', ', map { $_->address } @it), ")\n" if $debug > 0;
   return @it;
}

## The scan_control_file() function scans the control file specified in the
## given path; returns an array containing a code (0 = ok, -ve = reject,
## +ve = freeze), a comment, and a string containing identification info.
## For normal use the first two codes are sent to standard output.

sub scan_control_file ($;$$$$) {
   my ($file, $setproctitle_f_stchg, $setproctitle_f, $setproctitle_g, $exit) = @_;
   my ($code, $comment, $tag, $s1, $s2, $s3) = (0, 'Ok');

   my $prev_state = ZMailer_Message_File::START;
   my %envelope;		# rcvdfrom, with, identinfo, todsn, to
   my %header;			# from, sender, to, subject,...
   my $originating_ip;		# extracted from inside rcvdfrom
   my $message_size;		# excluding envelope
   my($text_size, $html_size);
   my($binary_p, $html_p);
   my $spamdex;
   my $proctitlebase;		# used in $f closure only

   get_self_addresses;
   get_interface_addresses;

   my $f = sub {
      my($state, $s, $type, $subtype) = @_;
      if ($prev_state != $state) {
	 &$setproctitle_f_stchg($state) if defined $setproctitle_f_stchg;
	 $binary_p = ($type && $type ne 'text');
	 $html_p = ($type && $type eq 'text' && $subtype =~ /^(html|xml)$/);
	 warn "state changed; now binary=$binary_p, html=$html_p\n"
	    if $debug > 2;
      }
      $_ = $s;
      $message_size += length unless $state == ZMailer_Message_File::ENVELOPE;
      $text_size += length unless $binary_p;
      $html_size += length if $html_p;
      &$setproctitle_f($message_size, $spamdex) if defined $setproctitle_f;
      chomp;
      warn "message size $message_size, data ($_)\n" if $debug > 2;
      if ($state == ZMailer_Message_File::ENVELOPE) {
	 if (/^(?:env-end$|From \S)/) {
	    ;
	 } elsif (/^(\S+)\s+(.*)$/) {	# key-value pairs
	    $envelope{$1} = $2;
	    $originating_ip = $1
		  if $1 eq 'rcvdfrom' && $2 =~ /\[(\d+\.\d+\.\d+\.\d+)\]:/;
	 } else {				# boolean parameters
	    $envelope{$_} = '';
	 }
	 $spamdex += spamdex($_, 1, 0, 0);
      } elsif (ZMailer_Message_File::state_is_head_p($state)) {
	 if (/^(\S+):\s*(.*)\s*$/) {		# This should always be the case
	    my($key, $val) = (lc($1), $2);
	    $header{$key} = $val if $state == ZMailer_Message_File::HEAD;
	    $spamdex += spamdex("$key: $val", 0, 1, 0);
	 }
      } elsif (ZMailer_Message_File::state_is_body_p($state)) {
	 $spamdex += spamdex($_, 0, 0, $html_p) unless $binary_p;
      } elsif (!ZMailer_Message_File::state_is_junk_p($state)) {
	 # This should never happen
	 die "Internal error: unknown state $state encountered";
      }
      $prev_state = $state;
   };

   my $g = sub {
      &$setproctitle_g($message_size, $spamdex) if defined $setproctitle_g;
      ## Try to analyse the message
      my $local_origin_p = !defined($envelope{external})
			|| local_ip_p($originating_ip);
      my $local_sender_p = !defined($envelope{from})
			|| local_domain_p($envelope{from});
      my $local_sender_ip_p = defined($envelope{from})
			&& ($envelope{from} =~ /\@\[(.*)\]$/)
			&& local_ip_p($envelope{$1});
      my $local_recipient_p = ($envelope{to} =~ /\@\[(\d+\.\d+\.\d+\.\d+)\]>$/)?
			   local_ip_p($1):
			   local_domain_p($envelope{to});
      my $message_size_in_k = $message_size/1024;
      my $sample_size_in_k = do { no integer; my $a =
			      int(($text_size - $html_size*0.75)/1024 + 0.5);
			      $a > $message_size_in_k? $message_size_in_k: $a };
      my $spamdex_average = $spamdex/
	    ($sample_size_in_k > 0? $sample_size_in_k: 1);

      warn sprintf
	   "message size %d (text %d, html %d); adjusted sample size %d k\n",
	    $message_size, $text_size, $html_size, $sample_size_in_k
	 if $debug > 0;

      if (!defined $envelope{from}) {	# locally generated
	 ## XXX hopefully no one forges anything on the local machine
	 ;
      } elsif ($envelope{channel} eq 'error'
	    && !$local_origin_p
	    && !$local_recipient_p
      ) {
	 ($code, $comment) = (-1,
	    'Error-trapped source, external origin, external destination');
      } elsif (!$local_sender_p && !$local_recipient_p) {
	 if ($local_origin_p) {
	    ## XXX hopefully no one forges anything on the local subnet
	    ($code, $comment) = (0, 'Ok, external source from local origin');
	 } else {
	    ($code, $comment) = (-1, 'External source, external desintation');
	 }
      ## case (!$local_origin_p, $local_sender_p) not checked as per RFC 2505
      } elsif (!$local_origin_p, $envelope{to} =~ /(^\@)|!|%|(\@.*\@)/) {
	 ($code, $comment) = (-1, 'External origin, source-routed destination');
      } elsif ($header{subject} =~ /\b(UCE|MMF|SEX)\s*\(\s*was\s*:.*\)\s*$/) {
	 ($code, $comment) = (0, 'Ok, abuse report');
      } elsif (!defined $header{from} && !defined $header{to}) {
	 ($code, $comment) = (1, 'No From or To headers');
      } elsif (!$local_origin_p && !defined $header{'message-id'}) {
	 ($code, $comment) = (1, 'External origin, no message identifier');
      } elsif (!$local_origin_p && $header{'message-id'} !~ /\s*<.*>\s*/) {
	 ($code, $comment) = (1,
	       'External origin, no <..> in message identifier');
      } elsif (!$local_origin_p && $header{'message-id'} !~ /^\s*<.*>\s*$/) {
	 ($code, $comment) = (1,
	       'External origin, junk before/after message identifier');
      } elsif (!$local_origin_p && $header{'message-id'} =~ /^\s*<\@.*>\s*$/) {
	 ($code, $comment) = (1,
	       'External origin, source route in message identifier');
      } elsif (!$local_origin_p && $header{from} !~ /\@/) {
	 ($code, $comment) = (1,
	       'External origin, unqualified sender: ' . $header{from});
      }
      if (!$code && defined $header{to}) {
	 for my $address (parse_mail_address($header{to})) {
	 last if $code < 0;			# get out if we are rejecting
	    if ($address =~ /^\@[^:]*$/) {	# syntax error, seen in spam
	       ($code, $comment) = (1,
		  'External origin, invalid recipient: ' . $header{to});
	    }
	 }
      }
      if (!$code && defined $header{'message-id'}) {
	 my @address = parse_mail_address($header{'message-id'});
	 if (scalar(@address) != 1) {
	    ($code, $comment) = (1, 'More than one message identifier');
	 }
      }
      if (!$code && $spamdex_average > $Spamdex::threshold) {
	 ($code, $comment) = (1, "Looks like spam ($spamdex_average)");
	 $comment .= ", Subject: $header{subject}" if $header{subject} =~ /\S/;
      }

      $tag .= ", origin=$originating_ip" if defined $originating_ip;
      $tag .= ", from=$envelope{from}" if defined $envelope{from};
      $tag .= ", to=$envelope{to}" if defined $envelope{to};
      $tag =~ s/^, //;
      ($s1, $s2, $s3) = ($spamdex, $sample_size_in_k, $spamdex_average);
   };

   ZMailer_Message_File::scan($file, $f, $g, undef, $exit);

   return ($code, $comment, $tag, $s1, $s2, $s3, \%envelope, \%header);
}

END {}

1;
