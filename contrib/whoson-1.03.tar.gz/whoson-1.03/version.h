/*
	$Id: version.h,v 1.9 1998/07/12 16:43:57 crosser Exp crosser $

	$Log: version.h,v $
	Revision 1.9  1998/07/12 16:43:57  crosser
	bump version: Change protocol: responce now is terminated with empty line

	Revision 1.8  1998/07/05 19:11:57  crosser
	bump version

	Revision 1.7  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.6  1998/07/05 00:01:27  crosser
	bump version

	Revision 1.5  1998/07/03 09:32:48  crosser
	bump version

	Revision 1.4  1998/07/02 18:04:20  crosser
	bump version

	Revision 1.3  1998/07/02 15:37:07  crosser
	bump version

	Revision 1.2  1998/07/01 21:57:57  crosser
	bump ver

	Revision 1.1  1998/07/01 21:55:16  crosser
	Initial revision

	Revision 1.1  1998/07/01 05:01:22  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef VERSION_H
#define VERSION_H

#define VERSION "1.03"

#endif
