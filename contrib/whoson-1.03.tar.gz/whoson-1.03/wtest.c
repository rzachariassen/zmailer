#include <stdio.h>
#include <string.h>
#include "whoson.h"

void main(int argc,char *argv[]) {
	char buf[128];
	int rc;

	for (;;) {	
		if (strcasecmp(argv[1],"login") == 0) {
			rc=wso_login(argv[2],argv[3],buf,sizeof(buf));
		} else if (strcasecmp(argv[1],"logout") == 0) {
			rc=wso_logout(argv[2],buf,sizeof(buf));
		} else if (strcasecmp(argv[1],"query") == 0) {
			rc=wso_query(argv[2],buf,sizeof(buf));
		} else {
			printf("bad usage\n");
			rc=-1;
		}

		printf("rc=%d, info=\"%s\"\n",rc,(rc>=0)?buf:"<irrelevant>");

		printf("again? ");fflush(stdout);
		fgets(buf,sizeof(buf)-1,stdin);
		if (buf[0] == 'n') break;
	}
}
