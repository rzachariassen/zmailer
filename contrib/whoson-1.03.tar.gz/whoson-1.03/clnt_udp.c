#ifndef LINT
static char *rcsid="$Id: clnt_udp.c,v 1.6 1998/07/12 16:43:57 crosser Exp crosser $";
#endif

/*
	$Log: clnt_udp.c,v $
	Revision 1.6  1998/07/12 16:43:57  crosser
	Change protocol: responce now is terminated with empty line

	Revision 1.5  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.4  1998/07/03 11:10:39  crosser
	fix include sys/time.h

	Revision 1.3  1998/07/02 18:01:15  crosser
	change error reporting to syslog

	Revision 1.2  1998/07/02 15:37:07  crosser
	check perms
	fix bug with excessive retries

	Revision 1.1  1998/07/01 21:55:16  crosser
	Initial revision

	Revision 1.2  1998/07/01 05:18:09  crosser
	minor warnings fix

	Revision 1.1  1998/07/01 05:01:22  crosser
	Initial revision

	Revision 1.1  1998/05/05 19:08:16  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#include "config.h"

#include <sys/types.h>
#include <time.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <netdb.h>
#ifdef HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "whoson.h"
#include "rtconfig.h"
#include "clnt_common.h"
#include "report.h"

#define MAXREQL 1024

#define INITTIMEOUT 100000
#define MAXTRIES 5

struct _udp_serv_rec {
	int port;
	char addr[16];
	unsigned long inittimeout;
	int maxtries;
};

int wso_udp_serv_connect(void *priv,char *buf)
{
	struct _udp_serv_rec *rec=(struct _udp_serv_rec *)(priv);
	struct sockaddr_in server,frominet;
	struct protoent *pe;
	int protonum;
	int fd;
	int len,slen;
	fd_set rfds,wfds,efds;
	struct timeval seltimer;
	unsigned long timeout;
	int tries,rc=0;

	memset((char *)&server,0,sizeof(server));
	server.sin_family = AF_INET;
	if ((pe=getprotobyname("udp"))) protonum=pe->p_proto;
	else protonum=17;
	server.sin_port=htons(rec->port);
	server.sin_addr.s_addr=inet_addr(rec->addr);
	if ((fd=socket(AF_INET,SOCK_DGRAM,protonum)) < 0) {
		ERRLOG((LOG_ERR,"[WHOSON] server socket: %m"))
		return -1;
	}

	timeout=rec->inittimeout;
	for (tries=0;tries<(rec->maxtries);tries++) {
		len=strlen(buf);
		if (sendto(fd,buf,len,0,(struct sockaddr *)&server,
				sizeof(server)) != len) {
			ERRLOG((LOG_ERR,"[WHOSON] sendto: %m"))
			close(fd);
			return -1;
		}

DPRINT(("udp waiting try=%d(%d max) timeout=%lu (init %lu)\n",
			tries,rec->maxtries,timeout,rec->inittimeout))

		seltimer.tv_sec=timeout/1000000L;
		seltimer.tv_usec=timeout%1000000L;
DPRINT(("seltimer.tv_sec=%lu, seltimer.tv_usec=%lu\n",
			seltimer.tv_sec,seltimer.tv_usec))
		FD_ZERO(&rfds);
		FD_ZERO(&wfds);
		FD_ZERO(&efds);
		FD_SET(fd,&rfds);

		rc=select(fd+1,&rfds,&wfds,&efds,&seltimer);
		if (rc < 0) {
			ERRLOG((LOG_ERR,"[WHOSON] select: %m"))
			close(fd);
			return -1;
		} else if (rc > 0) {
			break;
		}

		timeout *= 2;
	}

	if (rc == 0) {
		ERRLOG((LOG_ERR,"[WHOSON] udp excessive retries\n"))
		close(fd);
		return -1;
	}

	slen=sizeof(frominet);
	if ((len=recvfrom(fd,buf,MAXREQL-1,0,
			(struct sockaddr *) &frominet, &slen)) < 0) {
		ERRLOG((LOG_ERR,"[WHOSON] recvfrom: %m"))
		close(fd);
		return -1;
	}
	buf[len]='\0';

	close(fd);

	return 0;
}

int wso_udp_serv_cfg_init(void **priv)
{
	struct _udp_serv_rec *rec;

	if ((rec=(struct _udp_serv_rec *)malloc
				(sizeof(struct _udp_serv_rec)))) {
		memset(rec,0,sizeof(struct _udp_serv_rec));
		(*priv)=(void*)rec;
		rec->inittimeout=INITTIMEOUT;
		rec->maxtries=MAXTRIES;
		return 0;
	} else {
		ERRLOG((LOG_ERR,"[WHOSON] allocating struct _udp_serv_rec: %m"))
		return 1;
	}
}

int wso_udp_serv_cfg_next(char *key,char *val,void **priv)
{
	struct _udp_serv_rec *rec=(struct _udp_serv_rec *)(*priv);

	if (strcasecmp(key,"port") == 0) {
		rec->port=atoi(val);
	} else if (strcasecmp(key,"address") == 0) {
		strncpy(rec->addr,val,sizeof(rec->addr)-1);
		rec->addr[sizeof(rec->addr)-1]='\0';
	} else if (strcasecmp(key,"inittimeout") == 0) {
		rec->inittimeout=atol(val);
	} else if (strcasecmp(key,"maxtries") == 0) {
		rec->maxtries=atoi(val);
	} else {
		ERRLOG((LOG_ERR,"[WHOSON] bad keyword \"%s\"\n",key))
		return 1;
	}

	return 0;
}

int wso_udp_serv_cfg_end(void **priv)
{
	struct _udp_serv_rec *rec=(struct _udp_serv_rec *)(*priv);
	int d1,d2,d3,d4;

	if (rec->port == 0) {
		ERRLOG((LOG_ERR,"[WHOSON] bad port value \"%d\"\n",rec->port))
		return 1;
	} else if (rec->inittimeout == 0L) {
		ERRLOG((LOG_ERR,"[WHOSON] bad init timeout value \"%lu\"\n",
					rec->inittimeout))
		return 1;
	} else if (rec->maxtries == 0) {
		ERRLOG((LOG_ERR,"[WHOSON] bad init maxtries value \"%d\"\n",
					rec->maxtries))
		return 1;
	} else if (sscanf(rec->addr,"%d.%d.%d.%d",&d1,&d2,&d3,&d4) != 4) {
		ERRLOG((LOG_ERR,"[WHOSON] bad addr value \"%s\"\n",rec->addr))
		return 1;
	} else
		return 0;
}
