/*
	$Id: checkperm.h,v 1.4 1998/07/26 14:06:40 crosser Exp $

	$Log: checkperm.h,v $
	Revision 1.4  1998/07/26 14:06:40  crosser
	make it sutable for client too (extern names)

	Revision 1.3  1998/07/12 16:43:57  crosser
	change err. msg due to change in protocol

	Revision 1.2  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.1  1998/07/02 15:37:07  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef CHECKPERM_H
#define CHECKPERM_H

#define NOPERM "*Access denied\r\n\r\n"

struct _perm {
	struct _perm *next;
	int allow;	/* 1 - allow, 0 - deny */
	unsigned long pattern;
	unsigned long mask;
	int weight;
};

struct _perm *wso_perm_parse(int allow,char *what);
int wso_perm_check(struct _perm *chain,unsigned long addr);

#endif
