#include <sys/types.h>
#include "whoson.h"
#include "rtconfig.h"

int wso_unix_serv_cfg_init(void **priv);
int wso_unix_serv_cfg_next(char *key,char *val,void **priv);
int wso_unix_serv_cfg_end(void **priv);
struct _evdesc wso_unix_serv_connect(void *priv);

int wso_tcp_serv_cfg_init(void **priv);
int wso_tcp_serv_cfg_next(char *key,char *val,void **priv);
int wso_tcp_serv_cfg_end(void **priv);
struct _evdesc wso_tcp_serv_connect(void *priv);

int wso_udp_serv_cfg_init(void **priv);
int wso_udp_serv_cfg_next(char *key,char *val,void **priv);
int wso_udp_serv_cfg_end(void **priv);
struct _evdesc wso_udp_serv_connect(void *priv);

struct _cfgrec wso_servlist[] = {
	{"tcp",wso_tcp_serv_cfg_init,wso_tcp_serv_cfg_next,
			wso_tcp_serv_cfg_end,{wso_tcp_serv_connect}},
	{"udp",wso_udp_serv_cfg_init,wso_udp_serv_cfg_next,
			wso_udp_serv_cfg_end,{wso_udp_serv_connect}},
	{"unix",wso_unix_serv_cfg_init,wso_unix_serv_cfg_next,
			wso_unix_serv_cfg_end,{wso_unix_serv_connect}},
	{(void*)0,(void*)0,(void*)0,(void*)0,{(void*)0}}
};
