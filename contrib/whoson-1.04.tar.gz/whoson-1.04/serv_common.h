/*
	$Id: serv_common.h,v 1.3 1998/07/05 00:26:18 crosser Exp $

	$Log: serv_common.h,v $
	Revision 1.3  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.2  1998/07/05 00:01:27  crosser
	add user and group global parms

	Revision 1.1  1998/07/01 05:01:22  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef SERV_COMMON_H
#define SERV_COMMON_H

extern uid_t runuid;
extern uid_t rungid;

void do_request(char *req,char *retbuf,int retsize);

#endif
