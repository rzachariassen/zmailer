/*
	$Id: whosond.h,v 1.2 1998/07/05 00:26:18 crosser Exp $

	$Log: whosond.h,v $
	Revision 1.2  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.1  1998/07/01 05:01:22  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef WHOSOND_H
#define WHOSOND_H

struct _evdesc {
	int fd;
	struct _evdesc (*evproc) (int fd, void *priv);
	time_t ttl;
	void *priv;
};

void mainloop(struct _evdesc (*evvec[]) (int fd, void *priv), void *priv[]);

#endif
