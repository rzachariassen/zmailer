/*
	$Id: whoson.h,v 1.4 1998/07/05 00:26:18 crosser Exp $

	$Log: whoson.h,v $
	Revision 1.4  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.3  1998/07/03 11:10:39  crosser
	add wso_version()

	Revision 1.2  1998/07/02 18:01:15  crosser
	change API

	Revision 1.1  1998/05/05 19:08:16  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef WHOSON_H
#define WHOSON_H

char *wso_version(void);

int wso_login(char *addr,char *name,char *buf,int buflen);

int wso_logout(char *addr,char *buf,int buflen);

int wso_query(char *addr,char *buf,int buflen);

#endif
