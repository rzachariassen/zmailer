/*
	$Id: report.h,v 1.2 1998/07/05 00:26:18 crosser Exp $

	$Log: report.h,v $
	Revision 1.2  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.1  1998/07/02 18:01:15  crosser
	Initial revision

	Revision 1.1  1998/07/01 05:01:22  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef REPORT_H
#define REPORT_H

extern int wso_verbose;

#if 1
# define DPRINT(x) {if (wso_verbose) printf x;}
#else
# define DPRINT(x)
#endif

#ifdef HAVE_SYSLOG

#include <syslog.h>
#define ERRLOG(x) syslog x;

#else

#define ERRLOG(x)

#endif

#endif
