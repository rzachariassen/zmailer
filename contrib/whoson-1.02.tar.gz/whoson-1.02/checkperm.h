/*
	$Id: checkperm.h,v 1.2 1998/07/05 00:26:18 crosser Exp $

	$Log: checkperm.h,v $
	Revision 1.2  1998/07/05 00:26:18  crosser
	Change copyright

	Revision 1.1  1998/07/02 15:37:07  crosser
	Initial revision

*/

/*
	WHAT IS IT:
		Implementation of experimental "whoson" protocol
	AUTHOR:
		Eugene G. Crosser <crosser@average.org>
	COPYRIGHT:
		Public domain
*/

#ifndef CHECKPERM_H
#define CHECKPERM_H

#define NOPERM "*Access denied\r\n"

struct _perm {
	struct _perm *next;
	int allow;	/* 1 - allow, 0 - deny */
	unsigned long pattern;
	unsigned long mask;
	int weight;
};

struct _perm *perm_parse(int allow,char *what);
int perm_check(struct _perm *chain,unsigned long addr);

#endif
